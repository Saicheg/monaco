<?php ob_start() ?>
<?php 
if ($_GET['randomId'] != "kvLC3yzrmT9pkFYDz_G1Ys2eA7dkuc3aIUDW_Uh44KmM_1EJJ9pJkrz1hBzs64buNCJbrBlvTwtpSloeySrMTrbfRnpOiI0pRmM5Ska1jy6APz5K6j6quEYCeJpomFkfyZce2gn5ecoyPrs4gdTRdDIyWNCkMRneq6C6__T5SfG_h0dS4UHm2N1QfmF75PhKRZNKNVkYiWq13gwA4eP5m0JN3euIc0aBjiyrfwmgn23H1ue5Q492NgzIcNPN6ByC") {
	echo "Access Denied";
	exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Editing contact.html</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">body {background-color:threedface; border: 0px 0px; padding: 0px 0px; margin: 0px 0px}</style>
</head>
<body>
<div align="center">
<script language="javascript">
<!--//
// this function updates the code in the textarea and then closes this window
function do_save() {
	var code =  htmlCode.getCode();
	document.open();
	document.write("<html><form METHOD=POST name=mform action='https://cs19.simplehost.com:2083/frontend/x2/files/savehtmlfile.html'><input type=hidden name=dir value='/home/monaco/public_html'><input type=hidden name=file value='contact.html'>Saving ....<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><textarea name=page rows=1 cols=1></textarea></form></html>");
	document.close();
	document.mform.page.value = code;
	document.mform.submit();
}
function do_abort() {
	var code =  htmlCode.getCode();
	document.open();
	document.write("<html><form METHOD=POST name=mform action='https://cs19.simplehost.com:2083/frontend/x2/files/aborthtmlfile.html'><input type=hidden name=dir value='/home/monaco/public_html'><input type=hidden name=file value='contact.html'>Aborting Edit ....</form></html>");
	document.close();
	document.mform.submit();
}
//-->
</script>
<?php
// make sure these includes point correctly:
include_once ('/home/monaco/public_html/WysiwygPro/editor_files/config.php');
include_once ('/home/monaco/public_html/WysiwygPro/editor_files/editor_class.php');

// create a new instance of the wysiwygPro class:
$editor = new wysiwygPro();

// add a custom save button:
$editor->addbutton('Save', 'before:print', 'do_save();', WP_WEB_DIRECTORY.'images/save.gif', 22, 22, 'undo');

// add a custom cancel button:
$editor->addbutton('Cancel', 'before:print', 'do_abort();', WP_WEB_DIRECTORY.'images/cancel.gif', 22, 22, 'undo');

$body = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Home Page</title>
</head>
<body bgcolor="#c0dffd">&lt;!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> <!-- DW6 --><!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="mm_travel2.css" type="text/css" rel="stylesheet">
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css"><!--
.style3 {font-size: 18px}
.style6 {font-size: 32px}
.style11 {font-size: 1px}
--></style>
<table cellspacing="0" cellpadding="0" width="100%" border="0">
<tbody>
<tr bgcolor="#3366cc">
<td width="382" colspan="3" rowspan="2">
<img height="127" alt="Header image" src="mm_travel_photo.jpg" width="382" border="0"></td>
<td id="logo" valign="bottom" nowrap="nowrap" align="center" width="378" colspan="3" height="63">
<div class="style6" align="center">The Monaco Motel </div></td>
<td width="100%">&nbsp;</td></tr>
<tr bgcolor="#3366cc">
<td id="tagline" valign="top" align="center" colspan="3" height="64">
<div align="center">Contact </div></td>
<td width="100%">&nbsp;</td></tr>
<tr>
<td bgcolor="#003366" colspan="7">
<img height="1" alt="" src="mm_spacer.gif" width="1" border="0"></td></tr>
<tr bgcolor="#ccff99">
<td id="dateformat" colspan="7" height="25">  
<script language="JavaScript" type="text/javascript">
      document.write(TODAY);	</script> </td></tr>
<tr>
<td bgcolor="#003366" colspan="7">
<img height="1" alt="" src="mm_spacer.gif" width="1" border="0"></td></tr>
<tr>
<td valign="top" width="165" bgcolor="#e6f3ff">
<table id="navigation" cellspacing="0" cellpadding="0" width="165" border="0">
<tbody>
<tr>
<td width="165"> 
<br> 
<br></td></tr>
<tr>
<td width="165"><a class="navText" href="index.html">Home </a></td></tr>
<tr>
<td width="165"><a class="navText" href="rooms.html">Rooms </a></td></tr>
<tr>
<td><a class="navText" href="rates.html">Rates</a></td></tr>
<tr>
<td width="165"><a class="navText" href="events.html">Events</a></td></tr>
<tr>
<td><a class="navText" href="coupons.html">Coupons</a></td></tr>
<tr>
<td width="165"><a class="navText" href="specials.html">Special Services</a></td></tr>
<tr>
<td width="165"><a class="navText" href="javascript:;">Contact</a></td></tr></tbody></table> 
<br> 
<br> 
<br> 
<br></td>
<td width="50">
<img height="1" alt="" src="mm_spacer.gif" width="50" border="0"></td>
<td valign="top" width="305" colspan="2">
<img height="1" alt="" src="mm_spacer.gif" width="305" border="0">
<br> 
<br> 
<br>
<table cellspacing="0" cellpadding="0" width="318" border="0">
<tbody>
<tr>
<td class="pageName" width="372">
<p align="center">&nbsp;</p></td></tr>
<tr>
<td class="bodyText">
<h2 class="style3" align="center">&nbsp;</h2>
<h2 align="center">The Monaco Motel </h2>
<h2 align="center">4211 Ocean Avenue </h2>
<h2 align="center">Wildwood, New Jersey </h2>
<h2 align="center">08260 </h2>
<h2 align="center">Phone (609) 522-2269 </h2>
<h2 align="center">MonacoMotel@hotmail.com</h2>
<h2 class="style3" align="center">&nbsp;</h2></td></tr></tbody></table> 
<p>
<br>  </p>   
<h1 class="style3" align="center">Driving <a href="http://maps.yahoo.com//dd?taddr=4211+Ocean+Ave&amp;tcsz=Wildwood+NJ+08260" target="_blank">Directions Here</a>! </h1>
<h1 class="style3" align="center">Interactive <a href="http://search.travel.yahoo.com/bin/search/map;_ylt=Ah2DA2xkzcpg3ke7QgqZBdziphQB?id=12309857&amp;num_result=10&amp;.title=Destination+Guide&amp;.done=http%3A%2F%2Ftravel.yahoo.com%2Fp-hotel-monaco_motel%3Di%26id%3D12309857&amp;zoom=9&amp;cat=none" target="_blank">Map Here</a>! </h1>
<h1 class="style3" align="center"><a href="http://search.travel.yahoo.com/bin/search/map;_ylt=Ah2DA2xkzcpg3ke7QgqZBdziphQB?id=12309857&amp;num_result=10&amp;.title=Destination+Guide&amp;.done=http%3A%2F%2Ftravel.yahoo.com%2Fp-hotel-monaco_motel%3Di%26id%3D12309857&amp;zoom=9&amp;cat=none" target="new">
<img height="185" alt="Wildwood, NJ Map" src="http://image.maps.yahoo.com/mapimage?MAPData=HDNaA_hyzy0SXJtnBmf2_Icuv3vRP0sqJR8HoK8SxxONSeR4s6T_W1zi.xxYlduQFYEAIYGrKPm_dAebMbnDKJr5.Bb6xkXD1ep0Wls7K3rvZ887GjS_KwDaJhEOpfwz" width="180" border="1"></a></h1>
<div>
<div>
<div align="center">
<p>&nbsp;</p>
<p>&nbsp;</p></div></div></div></td>
<td width="50">
<img height="1" alt="" src="mm_spacer.gif" width="50" border="0"></td>
<td valign="top" width="190">
<br> 
<br>
<table cellspacing="0" cellpadding="0" width="190" border="0">
<tbody>
<tr>
<td class="subHeader" align="center" colspan="3">Nearby Attractions Include:</td></tr>
<tr>
<td width="40">
<img height="1" alt="" src="mm_spacer.gif" width="40" border="0"></td>
<td class="smallText" id="sidebar" width="110">
<br>
<p><a href="http://www.moreyspiers.com/" target="_blank">
<img height="171" alt="Here is all the fun you can desire!" src="pier_logo.jpg" width="193" border="0"></a>
<br>Morey\'s Piers operates three amusement piers and two beachfront waterparks that are located on the Boardwalk and Beachfront of the Wildwoods...
<br><a href="http://www.moreyspiers.com/about.htm" target="_blank">Read more ></a></p>
<p><a href="http://www.capemaylewesferry.com/" target="_blank">
<img height="109" alt="The Cape May-Lewes Ferry is the most memorable way to travel between Delaware and New Jersey!" src="ferry_logo.jpg" width="155" border="0"></a>
<br>More than 11 million vehicles and 34 million passengers have crossed the 17-mile mouth of Delaware Bay via vessels of Cape May-Lewes Ferry during its interesting 40-year history of operations that began July 1, 1964. Up to 100 vehicles and 1,000 passengers today can board modern ferries
<br><a href="http://www.capemaylewesferry.com/history/history.html" target="_blank">Read more ></a></p> 
<br> 
<br> 
<br></td>
<td width="40">&nbsp;</td></tr></tbody></table></td>
<td width="100%">&nbsp;</td></tr>
<tr>
<td width="165">&nbsp;</td>
<td width="50">&nbsp;</td>
<td width="167">&nbsp;</td>
<td width="138"><span class="style11">he Monaco Motel 4211 Ocean Avenue Wildwood by-the-sea, New Jersey cheap lodging motel rooms, hotel rooms, reservations, discounts, special, by the beach, near the Boardwalk, near the Convention centre, 08260 Phone (609) 522-2269 MonacoMotel@hotmail.com </span></td>
<td width="50">&nbsp;</td>
<td width="190">&nbsp;</td>
<td width="100%">&nbsp;</td></tr></tbody></table>
</body>
</html>';

$editor->set_code($body);

// add a spacer:
$editor->addspacer('', 'after:cancel');

// print the editor to the browser:
$editor->print_editor('100%',450);

?>
</div>
</body>
</html>
<?php ob_end_flush() ?>
