<?php ob_start() ?>
<?php
if ($_GET['randomId'] != "uf7ALkmrX90XNds75TWUzafjAelatOYae05TVIwPeavbIgaYHynumZ3sxe5s2Nn_04xPB8KHPxSAghcRed_Z93i66sjqlpkDR0s43jA9LwpkHyFt8ItPDiZBuxuew74vyBqolJhnBrj_DjzkDsEfBZM561bpgLM4ZR8c_wqmow0iGg4P40GaQ8o69oMfD_5QCPCruq6IjdUNbvaqf9IjwtCYdMtL5C8SmCsd5IQMtb3DfHitulsHa3qDdJTXCMBl") {
    echo "Access Denied";
    exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Editing events.html</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">body {background-color:threedface; border: 0px 0px; padding: 0px 0px; margin: 0px 0px}</style>
</head>
<body>
<div align="center">

<div id="saveform" style="display:none;">
<form METHOD="POST" name=mform action="https://cp11.myhostcenter.com:2083/frontend/x3/filemanager/savehtmlfile.html">
    <input type="hidden" name="charset" value="iso-8859-1">
    <input type="hidden" name="baseurl" value="http://monacomotelwildwood.com/">
    <input type="hidden" name="basedir" value="/home/monaco/public_html/">
    <input type="hidden" name="udir" value="/home/monaco/public_html">
    <input type="hidden" name="ufile" value="events.html">
    <input type="hidden" name="dir" value="%2fhome%2fmonaco%2fpublic_html">
    <input type="hidden" name="file" value="events.html">
    <input type="hidden" name="doubledecode" value="1">
<textarea name=page rows=1 cols=1></textarea></form>
</div>
<div id="abortform" style="display:none;">
<form METHOD="POST" name="abortform" action="https://cp11.myhostcenter.com:2083/frontend/x3/filemanager/aborthtmlfile.html">
    <input type="hidden" name="charset" value="iso-8859-1">
    <input type="hidden" name="baseurl" value="http://monacomotelwildwood.com/">
    <input type="hidden" name="basedir" value="/home/monaco/public_html/">
    <input type="hidden" name="dir" value="%2fhome%2fmonaco%2fpublic_html">
        <input type="hidden" name="file" value="events.html">
    <input type="hidden" name="udir" value="/home/monaco/public_html">
    <input type="hidden" name="ufile" value="events.html">

        </form>
</div>
<script language="javascript">
<!--//

function setHtmlFilters(editor) {
// Design view filter
editor.addHTMLFilter('design', function (editor, html) {
        return html.replace(/\<meta\s+http\-equiv\="Content\-Type"[^\>]+\>/gi, '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
});

// Source view filter
editor.addHTMLFilter('source', function (editor, html) {
        return html.replace(/\<meta\s+http\-equiv\="Content\-Type"[^\>]+\>/gi, '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
});
}

// this function updates the code in the textarea and then closes this window
function do_save() {
    document.mform.page.value = WPro.editors[0].getValue();
	document.mform.submit();
}
function do_abort() {
	document.abortform.submit();
}
//-->
</script>
<?php
// make sure these includes point correctly:
include_once ('/usr/local/cpanel/base/3rdparty/wysiwygPro/wysiwygPro.class.php');

// create a new instance of the wysiwygPro class:
$editor = new wysiwygPro();

$editor->registerButton('save', 'Save',
        'do_save();', '##buttonURL##save.gif', 22, 22,
        'savehandler'); 
$editor->addRegisteredButton('save', 'before:print' );
$editor->addJSButtonStateHandler ('savehandler', 'function (EDITOR,srcElement,cid,inTable,inA,range){ 
        return "wproReady"; 
        }'); 


$editor->registerButton('cancel', 'Cancel',
        'do_abort();', '##buttonURL##close.gif', 22, 22,
        'cancelhandler'); 
$editor->addRegisteredButton('cancel', 'before:print' );
$editor->addJSButtonStateHandler ('cancelhandler', 'function (EDITOR,srcElement,cid,inTable,inA,range){ 
        return "wproReady"; 
        }'); 
$editor->theme = 'blue'; 
$editor->addJSEditorEvent('load', 'function(editor){editor.fullWindow();setHtmlFilters(editor);}');

$editor->baseURL = "http://monacomotelwildwood.com/";

$editor->loadValueFromFile('/home/monaco/public_html/events.html');

$editor->registerSeparator('savecan');

// add a spacer:
$editor->addRegisteredButton('savecan', 'after:cancel');

//$editor->set_charset('iso-8859-1');
$editor->mediaDir = '/home/monaco/public_html/';
$editor->mediaURL = 'http://monacomotelwildwood.com/';
$editor->imageDir = '/home/monaco/public_html/';
$editor->imageURL = 'http://monacomotelwildwood.com/';
$editor->documentDir = '/home/monaco/public_html/';
$editor->documentURL = 'http://monacomotelwildwood.com/';
$editor->emoticonDir = '/home/monaco/public_html/.smileys/';
$editor->emoticonURL = 'http://monacomotelwildwood.com/.smileys/';
$editor->loadPlugin('serverPreview'); 
$editor->plugins['serverPreview']->URL = 'http://monacomotelwildwood.com/.wysiwygPro_preview_c5611912db3d2f1de1c68c723f9511ad.php?randomId=uf7ALkmrX90XNds75TWUzafjAelatOYae05TVIwPeavbIgaYHynumZ3sxe5s2Nn_04xPB8KHPxSAghcRed_Z93i66sjqlpkDR0s43jA9LwpkHyFt8ItPDiZBuxuew74vyBqolJhnBrj_DjzkDsEfBZM561bpgLM4ZR8c_wqmow0iGg4P40GaQ8o69oMfD_5QCPCruq6IjdUNbvaqf9IjwtCYdMtL5C8SmCsd5IQMtb3DfHitulsHa3qDdJTXCMBl';
// print the editor to the browser:
$editor->htmlCharset = 'iso-8859-1';
$editor->urlFormat = 'relative';
$editor->display('100%','450');

?>
</div>
<script>

</script>

</body>
</html>
<?php ob_end_flush() ?>
