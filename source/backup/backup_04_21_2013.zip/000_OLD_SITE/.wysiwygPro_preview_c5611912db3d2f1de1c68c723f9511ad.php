<?php
if ($_GET['randomId'] != "uf7ALkmrX90XNds75TWUzafjAelatOYae05TVIwPeavbIgaYHynumZ3sxe5s2Nn_04xPB8KHPxSAghcRed_Z93i66sjqlpkDR0s43jA9LwpkHyFt8ItPDiZBuxuew74vyBqolJhnBrj_DjzkDsEfBZM561bpgLM4ZR8c_wqmow0iGg4P40GaQ8o69oMfD_5QCPCruq6IjdUNbvaqf9IjwtCYdMtL5C8SmCsd5IQMtb3DfHitulsHa3qDdJTXCMBl") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
